create database StuMIS
on primary(
	name=StuMIS_data,
	filename="E:\�������ѧ\java web ��ϰ\C15F3301ĳĳ\StuMIS_data.mdf",
	size=8mb,
	filegrowth=64mb
)
log on(
	name=StuMIS_log,
	filename="E:\�������ѧ\java web ��ϰ\C15F3301ĳĳ\StuMIS_log.ldf",
	size=8mb,
	filegrowth=64mb
)

use StuMIS

create table SuperAdmins(
	userName nvarchar(50) primary key,
	[password] nvarchar(50) not null
)

create table EducationAdmins(
	userName nvarchar(50) primary key,
	[password] nvarchar(50) not null,
	realName nvarchar(50),
	department nvarchar(50) ,
	phone nvarchar(50) 
)

create table Teachers
(
userName nvarchar(50) unique ,
[password] nvarchar(50) not null,
realName nvarchar(50),
department nvarchar(50) ,
phone nvarchar(50) ,
teacherNo nvarchar(50) primary key,
major nvarchar(50) 
)
create table Classes
(
classNo nvarchar(50) primary key,
className nvarchar(50) not null,
[year] nvarchar(50),
department nvarchar(50),
major nvarchar(50)
)

create table Students(
	userName nvarchar(50) unique ,
	[password] nvarchar(50) not null,
	realName nvarchar(50),
	phone nvarchar(50) ,
	stuNo nvarchar(50) primary key,
	classNo nvarchar(50),
	constraint FK_Students_Classes foreign key(classNo) references  Classes( classNo )
)

create table Courses
(
courseNo nvarchar(50) primary key,
courseName nvarchar(50) not null,
credit nvarchar(50) not null

)
 
create table SCs(
	stuNo nvarchar(50),
	courseNo nvarchar(50),
	score nvarchar(50),
	constraint PK_SCs primary key(stuNo,courseNo),
	constraint FK_SCs_Students foreign key(stuNo) references Students(stuNo),
	constraint FK_SCs_Courses foreign key(courseNo) references Courses(courseNo)
)

create table TCs

(
teacherNo nvarchar(50),
courseNo  nvarchar(50),
classNo  nvarchar(50),
semester  nvarchar(50),
constraint PK_TCs primary key(teacherNo ,courseNo ,classNo),
constraint FK_TCs_Teachers foreign key(teacherNo) references Teachers(teacherNo),
constraint FK_TCs_Courses foreign key(courseNo) references Courses(courseNo),
constraint FK_TCs_Classes foreign key(classNo ) references Classes(classNo)
)